<?php
/**
 * Created by PhpStorm.
 * User: Marc
 * Date: 5/8/2015
 * Time: 12:36 AM
 */
define("DB_SERVER", "127.0.0.1");
define("DB_USER", "images");
define("DB_PASSWORD", "images");
define("DB_NAME", "images");
